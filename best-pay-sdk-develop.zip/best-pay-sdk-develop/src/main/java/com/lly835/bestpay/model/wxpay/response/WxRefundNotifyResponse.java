package com.lly835.bestpay.model.wxpay.response;

/**
 * 微信退款结果异步通知
 * Created by 廖师兄
 * 2018-05-30 16:29
 */
public class WxRefundNotifyResponse {
}
